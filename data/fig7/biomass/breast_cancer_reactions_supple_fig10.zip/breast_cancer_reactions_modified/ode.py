from .name2idx import C, V
from .reaction_network import ReactionNetwork


class DifferentialEquation(ReactionNetwork):
    def __init__(self, perturbation):
        super(DifferentialEquation, self).__init__()
        self.perturbation = perturbation

    def diffeq(self, t, y, *x):
        """Kinetic equations"""
        v = self.flux(t, y, x)

        if self.perturbation:
            for i, dv in self.perturbation.items():
                v[i] = v[i] * dv

        dydt = [0] * V.NUM
        dydt[V.RAS_inact] = - v[1] - v[3] - v[4] - v[6] - v[8]
        dydt[V.RAS_act] = + v[1] + v[3] + v[4] + v[6] + v[8]
        dydt[V.PI3K_inact] = - v[2] - v[5] - v[7]
        dydt[V.PI3K_act] = + v[2] + v[5] + v[7]
        dydt[V.RAF1_inact] = - v[9] + v[12]
        dydt[V.RAF1_act] = + v[9] - v[12]
        dydt[V.AKT_inact] = - v[10] - v[11] - v[32]
        dydt[V.AKT_p] = + v[10] + v[11] + v[32] - v[44]
        dydt[V.Heregulin] = - v[13]
        dydt[V.HER3] = - v[13]
        dydt[V.Heregulin_HER3] = + v[13] - v[14]
        dydt[V.HER2] = - v[14] - v[21]
        dydt[V.Heregulin_HER3_HER2] = + v[14] - v[15]
        dydt[V.Heregulin_HER3_HER2_p] = + v[15]
        dydt[V.EGF] = - v[16]
        dydt[V.EGFR] = - v[16] - 2 * v[19] - v[21] - v[35]
        dydt[V.EGF_EGFR] = + v[16] - 2 * v[17]
        dydt[V.EGF_EGFR_EGF_EGFR] = + v[17] - v[18]
        dydt[V.EGF_EGFR_p] = + v[18]
        dydt[V.EGFR_EGFR] = + v[19] - v[20]
        dydt[V.EGFR_EGFR_p] = + v[20]
        dydt[V.EGFR_HER2] = + v[21] - v[22]
        dydt[V.EGFR_HER2_p] = + v[22]
        dydt[V.Shc] = - v[23]
        dydt[V.Shc_p] = + v[23] - v[41]
        dydt[V.MEK] = - v[24]
        dydt[V.MEK_p] = + v[24] - v[42]
        dydt[V.ERK] = - v[25] + v[37]
        dydt[V.ERK_p_cytoplasm] = + v[25] - v[26] - v[37]
        dydt[V.ERK_p_nucleus] = + v[26]
        dydt[V.RSK] = - v[27]
        dydt[V.RSK_p] = + v[27] - v[43]
        dydt[V.cFOS] = - v[28] + v[51] - v[52] + v[53]
        dydt[V.cFOS_p] = + v[28] - v[29] - v[53]
        dydt[V.PIP2] = - v[30] + v[31]
        dydt[V.PIP3] = + v[30] - v[31]
        dydt[V.GSK3B] = - v[33]
        dydt[V.GSK3B_p] = + v[33] - v[45]
        dydt[V.CDKN1A] = - v[34] + v[39] - v[40]
        dydt[V.DUSP] = + v[36] - v[46]
        dydt[V.SPRY] = + v[38] - v[47]
        dydt[V.cFOS_mRNA] = + v[50]

        return dydt


def param_values():
    """Parameter values"""
    x = [1] * C.NUM
    x[C.V_Heregulin_HER3_HER2_p_RAS] = 4.830e+00
    x[C.K_Heregulin_HER3_HER2_p_RAS] = 5.478e-01
    x[C.V_Heregulin_HER3_HER2_p_PI3K] = 6.189e-01
    x[C.K_Heregulin_HER3_HER2_p_PI3K] = 4.458e-01
    x[C.V_EGF_EGFR_p_RAS] = 3.373e+00
    x[C.K_EGF_EGFR_p_RAS] = 2.111e-01
    x[C.V_EGFR_EGFR_p_RAS] = 5.961e+00
    x[C.K_EGFR_EGFR_p_RAS] = 2.793e+00
    x[C.V_EGFR_EGFR_p_PI3K] = 1.036e+00
    x[C.K_EGFR_EGFR_p_PI3K] = 1.782e+00
    x[C.V_EGFR_HER2_p_RAS] = 6.574e-01
    x[C.K_EGFR_HER2_p_RAS] = 3.177e-01
    x[C.V_EGFR_HER2_p_PI3K] = 5.423e+00
    x[C.K_EGFR_HER2_p_PI3K] = 1.518e-01
    x[C.V_Shc_p_RAS] = 9.885e-01
    x[C.K_Shc_p_RAS] = 1.418e+00
    x[C.V_RAS_RAF1] = 1.162e-01
    x[C.K_RAS_RAF1] = 1.567e-01
    x[C.V_PI3K_AKT] = 3.055e+00
    x[C.K_PI3K_AKT] = 1.677e+00
    x[C.V_PIP3_AKT] = 3.357e+00
    x[C.K_PIP3_AKT] = 4.248e+00
    x[C.V_SPRYiRAF1] = 7.606e+00
    x[C.K_RAF1i] = 2.809e+00
    x[C.kf13] = 2.887e+00
    x[C.kr13] = 4.484e+00
    x[C.kf14] = 3.315e-01
    x[C.kr14] = 1.487e+00
    x[C.kf15] = 2.582e+00
    x[C.kr15] = 1.164e+00
    x[C.kf16] = 5.584e-01
    x[C.kr16] = 4.548e+00
    x[C.kf17] = 4.691e+00
    x[C.kr17] = 6.472e-01
    x[C.kf18] = 2.469e+00
    x[C.kr18] = 7.556e-01
    x[C.kf19] = 7.765e-01
    x[C.kr19] = 2.171e+00
    x[C.kf20] = 2.227e+00
    x[C.kr20] = 2.365e+00
    x[C.kf21] = 7.804e+00
    x[C.kr21] = 2.124e-01
    x[C.kf22] = 1.155e-01
    x[C.kr22] = 7.303e+00
    x[C.V23] = 3.746e+00
    x[C.K23] = 1.811e-01
    x[C.V24] = 9.050e-01
    x[C.K24] = 1.096e-01
    x[C.V25] = 1.109e-01
    x[C.K25] = 5.513e+00
    x[C.kf26] = 2.005e+00
    x[C.kr26] = 3.212e-01
    x[C.V27] = 4.516e-04
    x[C.K27] = 5.826e+02
    x[C.V28] = 3.864e+00
    x[C.K28] = 1.029e+03
    x[C.kf29] = 5.382e-07
    x[C.V30] = 1.573e-01
    x[C.K30] = 2.446e-01
    x[C.V31] = 7.653e+00
    x[C.K31] = 1.331e+00
    x[C.V32] = 8.845e-01
    x[C.K32] = 3.608e-01
    x[C.V33] = 1.558e+00
    x[C.K33] = 1.948e-01
    x[C.kf34] = 4.130e+00
    x[C.kf35] = 1.378e-01
    x[C.V36] = 1.226e-01
    x[C.K36] = 6.473e-01
    x[C.n36] = 2.060e-01
    x[C.V37] = 1.850e-01
    x[C.K37] = 8.398e+00
    x[C.V38] = 9.847e-01
    x[C.K38] = 1.262e-01
    x[C.n38] = 1.425e-01
    x[C.V39] = 1.307e+00
    x[C.K39] = 1.860e-01
    x[C.n39] = 6.435e+00
    x[C.kf40] = 5.660e-01
    x[C.kf41] = 9.594e-04
    x[C.kf42] = 5.161e-04
    x[C.kf43] = 2.185e-02
    x[C.kf44] = 1.479e-03
    x[C.kf45] = 1.546e-03
    x[C.kf46] = 3.375e-03
    x[C.kf47] = 3.268e-03
    x[C.V50] = 9.406e-02
    x[C.K50] = 6.364e+01
    x[C.n50] = 8.047e+00
    x[C.kf51] = 2.482e+02
    x[C.kf52] = 1.477e-02
    x[C.V53] = 3.891e-02
    x[C.K53] = 3.400e+01
    x[C.K_FOSi_cFOSmRNA] = 1.261e-04
    x[C.K_ERK_cFOSp] = 2.390e-01
    x[C.n_ERK_cFOSp] = 1.844e+00
    x[C.K_RSKi_ERK_RSK] = 3.295e+00

    return x


def initial_values():
    """Values of the initial condition"""
    y0 = [0] * V.NUM
    y0[V.RAS_inact] = 1.00e02
    y0[V.PI3K_inact] = 1.00e02
    y0[V.RAF1_inact] = 1.00e02
    y0[V.AKT_inact] = 1.00e02
    y0[V.HER3] = 1.00e02
    y0[V.HER2] = 1.00e02
    y0[V.EGFR] = 1.00e02
    y0[V.Shc] = 1.00e02
    y0[V.MEK] = 1.00e02
    y0[V.ERK] = 9.60e02
    y0[V.RSK] = 3.53e02
    y0[V.cFOS] = 0
    y0[V.PIP2] = 1.00e02
    y0[V.PTEN] = 1.00e02
    y0[V.GSK3B] = 1.00e02

    return y0
